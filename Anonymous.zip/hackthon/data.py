import pandas as pd
import numpy as np

pd.set_option('display.width', 400)
pd.set_option('display.max_columns', 11)

# Credentials to connect to the database
username = "username"
password = "DB_password"
hostname = "DB_host"
dbname = "DB_name"


def generate_random_data(num_rows=1000):
    np.random.seed(42)  # Set seed for reproducibility

    # Generate random data
    random_dates = pd.date_range(start='2022-01-01', end='2022-12-31', freq='D')
    data = pd.DataFrame({
        'order_timestamp': np.random.choice(random_dates, size=num_rows),
        'product_id': np.random.randint(1, 101, size=num_rows),  # Assuming product IDs range from 1 to 100
        'product_quantity': np.random.randint(1, 11, size=num_rows),  # Random quantity between 1 and 10
        'product_price': np.random.uniform(10, 100, size=num_rows),  # Random price between 10 and 100
    })

    return data


def first_data_handle():
    data = generate_random_data()

    # Round the prices so as to have two decimals
    data.product_price = round(data.product_price, 2)

    # Find the data with zero product_price
    zero_price_data = data.where(data.product_price == 0.0).dropna(axis=0)

    # Remove the zero price data
    data.drop(zero_price_data.index, axis=0, inplace=True)
    data.index = range(len(data))

    with pd.option_context('mode.use_inf_as_na', True):
        data = data.dropna(axis=0)

    data.index = range(len(data))

    # Display random generated data
    print_details(data)

    # You can still write the processed data to SQL table if needed
    # engine = create_engine("mysql+mysqlconnector://{user}:{password}@{host}/{dbname}"
    #                        .format(user=username,
    #                                password=password,
    #                                host=hostname,
    #                                dbname=dbname))
    # data.to_sql(name="sales", con=engine, if_exists="replace", index=False, chunksize=1000)


# ... (other functions remain unchanged)

# Helpful function to see the details of a dataframe
def print_details(data):
    print("Number of customers: {}".format(data.customer_id.nunique()))
    print("Number of orders: {}".format(data.order_id.nunique()))
    print("Number of products: {}".format(data.product_id.nunique()))
    print("First date: {}".format(data.order_timestamp.min()))
    print("Last date: {}".format(data.order_timestamp.max()))
    print("Columns in data:")
    print(list(data.columns))
    print(data.shape)
    print(data.head(10))
    print(data.tail(10))


# Execute the function to see random generated data details
first_data_handle()
