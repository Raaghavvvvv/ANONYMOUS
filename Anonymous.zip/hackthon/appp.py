from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_price', methods=['POST'])
def get_price():
    try:
        data = request.get_json()
        current_price = data['current_price']

        # Placeholder for a simple pricing strategy (e.g., 10% increase)
        new_price = current_price * 1.1

        return jsonify({"new_price": new_price})

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
