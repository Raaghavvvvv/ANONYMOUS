import json
import random

def generate_random_model_output():
    random.seed()  # Initialize the random number generator without a specific seed
    best_price = round(random.uniform(20, 30), 1)
    predicted_quantity = random.randint(100, 200)
    predicted_gain = random.randint(4000, 6000)

    return {
        'best_price': best_price,
        'predicted_quantity': predicted_quantity,
        'predicted_gain': predicted_gain
    }

if __name__ == "__main__":
    generated_output = generate_random_model_output()

    # Print the generated output in JSON format
    json_output = json.dumps(generated_output, indent=2)
    print(json_output)
